package gamecomponents;

public class FarkleDie extends Die {
	private boolean holdValue = false;
	
	
	public FarkleDie() {
		Die myDie = new Die();
		holdValue = false;
	}
	
	public void hold() {
		holdValue = true;
	}
	
	public boolean isHeld() {
		return holdValue;
	}
	public void release() {
		holdValue = false;
	}

}
