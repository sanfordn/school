package gamecomponents;

import java.util.*;

public class FarkleDice {
	
	
	private ArrayList<FarkleDie> farkleDieList;
	private FarkleDie die1;
	private FarkleDie die2;
	private FarkleDie die3;
	private FarkleDie die4;
	private FarkleDie die5;
	private FarkleDie die6;

	public FarkleDice() {
		die1 = new FarkleDie();
		die2 = new FarkleDie();
		die3 = new FarkleDie();
		die4 = new FarkleDie();
		die5 = new FarkleDie();
		die6 = new FarkleDie();
	}
	
	public ArrayList<Integer> rollDice() {
		ArrayList<Integer> dieList = new ArrayList<Integer>();
		dieList.add(0,die1.roll());
		dieList.add(1,die2.roll());
		dieList.add(2,die3.roll());
		dieList.add(3,die4.roll());
		dieList.add(die5.roll());
		dieList.add(die6.roll());
		return dieList;
	}
	
	public void hold(int dieNum) {
		switch (dieNum) {
		case 1:
			die1.hold();
			break;
		case 2:
			die2.hold();
			break;
		case 3:
			die3.hold();
			break;
		case 4:
			die4.hold();
			break;
		case 5:
			die5.hold();
			break;
		case 6:
			die6.hold();
			break;
		}
	}

}
