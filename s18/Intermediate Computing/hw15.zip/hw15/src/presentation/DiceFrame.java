package presentation;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

/** 
 * The DieFrame class contains a Frame with two dice and a roll button.
 * 
 * @author Michael J. Holmes
 * @version 1.0 Dec 17, 2012.
 */
public class DiceFrame extends JFrame
{
	//----------------------------------------------------------------------------------
    // Instance Variables
	//----------------------------------------------------------------------------------
    private DiePanel die1;
    private DiePanel die2;
    private DiePanel die3;
    private DiePanel die4;
    private DiePanel die5;
    private DiePanel die6;
    private JPanel field;
    private JPanel menu;
   

    
	//----------------------------------------------------------------------------------
    // Constructors
	//----------------------------------------------------------------------------------    
    public DiceFrame()
    {
       /** 
        * Default constructor.
       */
    	
       // Initialize the frame properties
	   this.setLayout(new FlowLayout());
	   this.setSize( 300, 300 );
       this.setTitle( "Farkle" );


       this.createFieldPanel();
       this.createMenuPanel();
       

       //Add the field and menu panels to the frame.
       this.add(field);
       this.add(menu);
   }
   
    
	//----------------------------------------------------------------------------------
    // Class Methods
	//----------------------------------------------------------------------------------    
    
   
    

    
  
	//----------------------------------------------------------------------------------
    // Private Helpers
	//----------------------------------------------------------------------------------  

    /** 
     * Build the menu panel.
    */
    private void createMenuPanel()
    {
      //Set up the menu area.
      menu = new JPanel();
      menu.setBounds(0,300,250,100);
   
      //Create a button and add a listener to it.
      JButton rollButton = new JButton("Re-Roll");
      rollButton.setSize(300,200);
      JButton holdButton1 = new JButton("Hold Die 1");
      holdButton1.setSize(300,200);
      JButton holdButton2 = new JButton("Hold Die 2");
      holdButton2.setSize(300,200);
      JButton holdButton3 = new JButton("Hold Die 3");
      holdButton3.setSize(300,200);
      JButton holdButton4 = new JButton("Hold Die 4");
      holdButton4.setSize(300,200);
      JButton holdButton5 = new JButton("Hold Die 5");
      holdButton5.setSize(300,200);
      JButton holdButton6 = new JButton("Hold Die 6");
      holdButton6.setSize(300,200);
      JButton resetButton = new JButton("Reset");
      resetButton.setSize(300,200);
      
   
      rollButton.addActionListener(new RollListener());
      holdButton1.addActionListener(new HoldDie1Listener());
      holdButton2.addActionListener(new HoldDie2Listener());
      holdButton3.addActionListener(new HoldDie3Listener());
      holdButton4.addActionListener(new HoldDie4Listener());
      holdButton5.addActionListener(new HoldDie5Listener());
      holdButton6.addActionListener(new HoldDie6Listener());
      resetButton.addActionListener(new reset());
   
      //Add the button to the menu area.
      menu.add(holdButton1);
      menu.add(holdButton2);
      menu.add(holdButton3);
      menu.add(holdButton4);
      menu.add(holdButton5);
      menu.add(holdButton6);
      menu.add(rollButton);
      menu.add(resetButton);
    }
    
    
    /** 
     * Build the field panel.
    */
    private void createFieldPanel()
    {
        //Set up the dice field area.
        field = new JPanel();
        field.setBounds(0,0,250,200);
       
        //Create the dice and add them.
        die1 = new DiePanel();
        die2 = new DiePanel();
        die3 = new DiePanel();
        die4 = new DiePanel();
        die5 = new DiePanel();
        die6 = new DiePanel();
        field.add(die1);
        field.add(die2);
        field.add(die3);
        field.add(die4);
        field.add(die5);
        field.add(die6);
    	
    }
    
    private class reset implements ActionListener {
    		public void actionPerformed(ActionEvent e) {
    			die1.releaseDie();
    			die2.releaseDie();
    			die3.releaseDie();
    			die4.releaseDie();
    			die5.releaseDie();
    			die6.releaseDie();
    		}
    }
    
    
    
    
   private class RollListener implements ActionListener 
   {
       public void actionPerformed(ActionEvent e) 
       {
    	   if (!die1.isHeld()) {
    		   die1.rollDie();
    	   }
    	   if(!die2.isHeld()) {
    		   die2.rollDie();
    	   }
    	   if(!die3.isHeld()) {
    		   die3.rollDie();
    	   }
    	   if(!die4.isHeld()) {
    		   die4.rollDie();
    	   }
    	   if(!die5.isHeld()) {
    		   die5.rollDie();
    	   }
    	   if(!die6.isHeld()) {
    		   die6.rollDie();
    	   }
    	   		
    	   		
    	   		
    	   		
    	   		
       }
   }
   
   private class HoldDie1Listener implements ActionListener {
	   
	   public void actionPerformed(ActionEvent e) {
		   die1.holdDie();
	   }
	   
	   
   }
   private class HoldDie2Listener implements ActionListener {
	   
	   public void actionPerformed(ActionEvent e) {
		   die2.holdDie();
	   }
	   
	   
   }
   private class HoldDie3Listener implements ActionListener {
	   
	   public void actionPerformed(ActionEvent e) {
		   die3.holdDie();
	   }
	   
	   
   }
   private class HoldDie4Listener implements ActionListener {
	   
	   public void actionPerformed(ActionEvent e) {
		   die4.holdDie();
	   }
	   
	   
   }
   private class HoldDie5Listener implements ActionListener {
	   
	   public void actionPerformed(ActionEvent e) {
		   die5.holdDie();
	   }
	   
	   
   }
   private class HoldDie6Listener implements ActionListener {
	   
	   public void actionPerformed(ActionEvent e) {
		   die6.holdDie();
	   }
	   
	   
   }
   
   
   
}