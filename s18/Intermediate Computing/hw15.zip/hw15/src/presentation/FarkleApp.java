package presentation;
import gamecomponents.*;
import java.util.Scanner;


public class FarkleApp {
	public static void main(String[] args) {
		
		DiceFrame aBoard = new DiceFrame();
        
        aBoard.setVisible(true);
		
		
	}
	

}
