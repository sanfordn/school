
def search(problem):
    frontier = [problem]
    explored = []
    i = 0
    while True:
        if len(frontier) == 0:
            return "failure"
        node = frontier.pop()
        if node == "EEEEEEEEE" or node == "DDDDDDDDD" or node == "RRRRRRRRR":
            return explored
        explored.append(node)
        for i in range(len(node)):
            toAppend = expand(node, i)
            if toAppend not in frontier and toAppend not in explored:
                frontier.append(toAppend)

def helper():
    explored_nodes = search("DEDEEEDED")
    print(explored_nodes)


def expand(node, i):
    numList = changeGems(i)
    for j in numList:
        if node[j] == 'E':
            node[:j] + 'D' + node[(j+1):]
        elif node[j] == 'D':
            node[:j] + 'R' + node[(j+1):]
        elif node[j] == 'R':
            node[:j] + 'E' + node[(j+1):]
        else:
            print("problem with changing the gems.. exiting program. \n")
            exit(1)
    return node

def changeGems(i):
    nums = []
    if i == 0:
        nums.append(0)
        nums.append(1)
        nums.append(3)
    elif i == 1:
        nums.append(0)
        nums.append(1)
        nums.append(2)
        nums.append(4)
    elif i == 2:
        nums.append(1)
        nums.append(2)
        nums.append(5)
    elif i == 3:
        nums.append(0)
        nums.append(3)
        nums.append(4)
        nums.append(6)
    elif i == 4:
        nums.append(1)
        nums.append(3)
        nums.append(4)
        nums.append(5)
        nums.append(7)
    elif i == 5:
        nums.append(2)
        nums.append(4)
        nums.append(5)
        nums.append(8)
    elif i == 6:
        nums.append(3)
        nums.append(6)
        nums.append(7)
    elif i == 7:
        nums.append(4)
        nums.append(6)
        nums.append(7)
        nums.append(8)
    elif i == 8:
        nums.append(5)
        nums.append(7)
        nums.append(8)
    else:
        print("index to change is out of range.. exiting. \n")
        exit(1)

    return nums
        
    
